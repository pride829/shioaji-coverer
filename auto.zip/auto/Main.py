from AutoStopper import AutoStopper

autostopper = AutoStopper()

autostopper.startAutoStopper()